"""
HSE Management System
"""
